# SLASH-COMMANDS-BOT
Bot em slash

VOCÊ DEVE ADICIONAR COM O LINK DE PERM ABAIXO ( MUDE O ID ONDE ESTÁ ESCRITO "ID_DO_BOT"

https://discord.com/api/oauth2/authorize?client_id=ID_DO_BOT&permissions=8&scope=bot%20applications.commands
